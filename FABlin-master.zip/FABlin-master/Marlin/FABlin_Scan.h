#ifndef _FABLIN_SCAN_H_
#define _FABLIN_SCAN_H_

#define WORKING_MODE_SCAN 4

namespace Scan
{
	void enable (void);
	void disable (void);
}

#endif
